<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Designation;

class DesignationController extends Controller
{
    

      public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $designations=\App\Designation::latest()->paginate(4);
        return view('designation\index',compact('designations'))->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('designation.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Designation::create([
            'designation_name' => $request['designation_name']
        ]);
        return redirect()->route('designation.index')->with('success','Designation created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $designations = \App\Designation::find($id);
        return view('designation.show',compact('designations'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       //return view('designation.edit',compact('designation'));
        $designations = \App\Designation::find($id);
        return view('designation.edit',compact('designations','id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

     $designation= \App\Designation::find($id);
        $designation->designation_name=$request->get('designation_name');
        
        $designation->save();
        return redirect('designation')->with('success','Designation updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $designation = \App\Designation::find($id);
        $designation->delete();
        return redirect('designation')->with('success','Designation has been  deleted');
    }

    public function search(Request $request)
    {

     $constraints = [
         'designation_name' => $request['designation_name']
         ];

       $designations = $this->doSearchingQuery($constraints);
        return view('designation\index',compact('designations'))->with('i', (request()->input('page', 1) - 1) * 5);
    }

    private function doSearchingQuery($constraints) {
     $query = Designation::query();
     $fields = array_keys($constraints);
     $index = 0;
     foreach ($constraints as $constraint) {
         if ($constraint != null) {
             $query = $query->where( $fields[$index], 'like', '%'.$constraint.'%');
         }

         $index++;
     }
     return $query->latest()->paginate(4);
    }
}
