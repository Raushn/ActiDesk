<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function () {
    return view('dashboard');
})->middleware('auth');

Auth::routes();


//Route::get('/home', 'HomeController@index')->name('home');

Route::get('dashboard', 'DashboardController@index');
Route::get('profile', 'ProfileController@index');
Route::resource('employees','EmployeeManagementController');

Route::resource('attendance', 'AttendanceController');
Route::post('employees/pdf','EmployeeManagementController@export_pdf');


Route::resource('admin','AdminManagementController');

Route::post('designation/search', 'DesignationController@search');
Route::resource('designation','DesignationController');

Route::post('organization/search', 'OrganizationController@search');
Route::resource('organization','OrganizationController');





Route::resource('passports','PassportController');














//other routes
//Logged in users/employer cannot access or send requests these pages
Route::group(['middleware' => 'employer_guest'], function() {

Route::get('employerregister', 'EmployerAuth\RegisterController@showRegistrationForm');
Route::post('employerregister', 'EmployerAuth\RegisterController@register');

Route::get('employerlogin', 'EmployerAuth\LoginController@showLoginForm');
Route::post('employerlogin', 'EmployerAuth\LoginController@login');

//Password reset routes
Route::get('employerpassword/reset', 'EmployerAuth\ForgotPasswordController@showLinkRequestForm');
Route::post('employerpassword/email', 'EmployerAuth\ForgotPasswordController@sendResetLinkEmail');
Route::get('employerpassword/reset/{token}', 'EmployerAuth\ResetPasswordController@showResetForm');
Route::post('employerpassword/reset', 'EmployerAuth\ResetPasswordController@reset');

});

//Only logged in employers can access or send requests to these pages
Route::group(['middleware' => 'employer_auth'], function(){

Route::post('employerlogout', 'EmployerAuth\LoginController@logout');
Route::get('/employerhome', function(){
  return view('employer.home');
});
});