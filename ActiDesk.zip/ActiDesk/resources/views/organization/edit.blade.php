@extends('organization.base')
@section('action-content')
<div class="container">
     
        <form method="post" action="{{action('OrganizationController@update', $id)}}">
        @csrf
        <input name="_method" type="hidden" value="PATCH">
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="organization_name">Organization Name</label>
            <input type="text" class="form-control" name="organization_name" value="{{$organizations->organization_name}}">
          </div>
        </div>
      
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="margin-top:60px">
            <button type="submit" class="btn btn-success" style="margin-left:38px">Update</button>
          </div>
        </div>
      </form>
    </div>

@endsection