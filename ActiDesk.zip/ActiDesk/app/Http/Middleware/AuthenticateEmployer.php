<?php

namespace App\Http\Middleware;

use Closure;

//Auth Facade
use Auth;

class AuthenticateEmployer
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        //If request comes from logged in user, he will
      //be redirect to home page.
      if (Auth::guard()->check()) {
          return redirect('/employerhome');
      }

        //If request does not comes from logged in employer
       //then he shall be redirected to Employer Login page
       if (! Auth::guard('web_employer')->check()) {
           return redirect('/employerlogin');
       }

        return $next($request);
    }
}
