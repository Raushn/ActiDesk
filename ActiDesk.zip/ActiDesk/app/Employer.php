<?php

namespace App;

//Class which implements Illuminate\Contracts\Auth\Authenticatable
use Illuminate\Foundation\Auth\User as Authenticatable;

//Trait for sending notifications in laravel
use Illuminate\Notifications\Notifiable;

//Notification for Employer
use App\Notifications\EmployerResetPasswordNotification;

class Employer extends Authenticatable
{

	// This trait has notify() method defined
  use Notifiable;

  //Mass assignable attributes
  protected $fillable = [
      'name','contact', 'email', 'password','address','organization_id','designation_id','date_of_joining','employee_code','date_of_birth','fathers_name','contact_2','nda','address_proof','pancard_no','photograph','tenth_marksheet','twelth_marksheet','graduation','adhar_card_no','customer_id','account_no',
  ];

  //hidden attributes
   protected $hidden = [
       'password', 'remember_token',
   ];

    //Send password reset notification
  public function sendPasswordResetNotification($token)
  {
      $this->notify(new EmployerResetPasswordNotification($token));
  }

}