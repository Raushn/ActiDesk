<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Passport extends Model
{
    protected $table = 'passports';
    protected $guarded = [];
}
