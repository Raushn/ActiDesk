@extends('designation.base')
@section('action-content')
<div class="container">
     
        <form method="post" action="{{action('DesignationController@update', $id)}}">
        @csrf
        <input name="_method" type="hidden" value="PATCH">
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="designation_name">Designation Name</label>
            <input type="text" class="form-control" name="designation_name" value="{{$designations->designation_name}}">
          </div>
        </div>
      
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="margin-top:60px">
            <button type="submit" class="btn btn-success" style="margin-left:38px">Update</button>
          </div>
        </div>
      </form>
    </div>

@endsection