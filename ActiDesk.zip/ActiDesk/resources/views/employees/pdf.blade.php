@extends('employees.base')
@section('action-content')
    <table class="table table-bordered">
      <tr>
       
                  <td>{{ $employees->id }}</td>
                  <td><img width="50px" height="50px" src="<?php echo asset("storage/app/avatars/employee/$employee->photograph") ?>"/></td>
                  <td class="sorting_1">{{ $employees->name }}</td>
                  <td class="hidden-xs">{{ $employees->contact }}</td>
                  <td class="hidden-xs">{{ $employees->email }}</td>
                  <td class="hidden-xs">{{ $employees->address }}</td>
                  <td class="hidden-xs">{{ $employees->organization }}</td>
                  <td class="hidden-xs">{{ $employees->designation }}</td>
                  <td class="hidden-xs">{{ $employees->date_of_joining }}</td>
                  <td class="hidden-xs">{{ $employees->employee_code }}</td>
                  <td class="hidden-xs">{{ $employees->date_of_birth }}</td>
                  <td class="hidden-xs">{{ $employees->fathers_name }}</td>
                  <td class="hidden-xs">{{ $employees->contact_2 }}</td>
                  <td class="hidden-xs">{{ $employees->nda }}</td>
                  <td class="hidden-xs">{{ $employees->address_proof }}</td>
                  <td class="hidden-xs">{{ $employees->pancard_no }}</td>
                  <td class="hidden-xs">{{ $employees->photograph }}</td>
                  <td class="hidden-xs">{{ $employees->tenth_marksheet }}</td>
                  <td class="hidden-xs">{{ $employees->twelth_marksheet }}</td>
                  <td class="hidden-xs">{{ $employees->graduation }}</td>
                  <td class="hidden-xs">{{ $employees->adhar_card_no }}</td>
                  <td class="hidden-xs">{{ $employees->customer_id }}</td>
                  <td class="hidden-xs">{{ $employees->account_no }}</td>
      </tr>
    </table>
@endsection