<?php $__env->startSection('action-content'); ?>
   <div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Organization Name</strong>
                <?php echo e($organizations->organization_name); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <?php if (isset($_GET['page'])) {
              $page=$_GET['page'];
            ?>
            <a  href="<?php echo e(route('organization.index',['page'=>$page])); ?>"><button type="button" class="btn btn-primary">
                Back
            </button></a>
            
            <?php } ?>
        </div>
       </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('organization.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>