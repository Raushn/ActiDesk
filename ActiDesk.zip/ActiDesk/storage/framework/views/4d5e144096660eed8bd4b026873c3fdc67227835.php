<?php $__env->startSection('action-content'); ?>
<div class="container">
     
        <form method="post" action="<?php echo e(action('EmployeeManagementController@update', $id)); ?>">
        <?php echo csrf_field(); ?>
        <input name="_method" type="hidden" value="PATCH">
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="organization_name">Name</label>
            <input type="text" class="form-control" name="name" value="<?php echo e($employees->name); ?>">
          </div>
       
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="email">Email Id</label>
            <input type="text" class="form-control" name="email" value="<?php echo e($employees->email); ?>">
          </div>
        
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="contact">Contact Number</label>
            <input type="text" class="form-control" name="contact" value="<?php echo e($employees->contact); ?>">
          </div>
        
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="Address">Address</label>
            <input type="text" class="form-control" name="address" value="<?php echo e($employees->address); ?>">
          </div>
        
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="organization_name">Organization Name</label>

            <select class="form-control" name="organization_id">
              <?php $__currentLoopData = $organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($organization->id); ?>" <?php echo e($organization->id == $employees->organization_id ? 'selected' : ''); ?>><?php echo e($organization->organization_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>               
           <!--  <input type="text" class="form-control" name="organization_name" value="<?php echo e($employees->organization_name); ?>"> -->
          </div> 
       
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="designation_name">Designation Name</label>
           <select class="form-control" name="organization_id">
              <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($designation->id); ?>"  <?php echo e($designation->id == $employees->designation_id ? 'selected' : ''); ?>><?php echo e($designation->designation_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>  
          </div>
       
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="date_of_joining">Date of Joining</label>
            <input type="text" class="form-control" name="date_of_joining" value="<?php echo e($employees->date_of_joining); ?>">
          </div>
       
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="employee_code">Employee Code</label>
            <input type="text" class="form-control" name="employee_code" value="<?php echo e($employees->employee_code); ?>">
          </div>

          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="date_of_birth">Date of Birth</label>
            <input type="text" class="form-control" name="date_of_birth" value="<?php echo e($employees->date_of_birth); ?>">
          </div>

          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="fathers_name">Fathers Name</label>
            <input type="text" class="form-control" name="fathers_name" value="<?php echo e($employees->fathers_name); ?>">
          </div>

          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="contact_2">Alternate Contact Number</label>
            <input type="text" class="form-control" name="contact_2" value="<?php echo e($employees->contact_2); ?>">
          </div>
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="nda">NDA</label>
            <input type="text" class="form-control" name="nda" value="<?php echo e($employees->nda); ?>">
          </div>
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="address_proof">Address Proof</label>
            <input type="text" class="form-control" name="address_proof" value="<?php echo e($employees->address_proof); ?>">
          </div>

          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="pancard_no">Pancard Number</label>
            <input type="text" class="form-control" name="pancard_no" value="<?php echo e($employees->pancard_no); ?>">
          </div>
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="photograph">Picture</label>
            <img src="<?php echo asset("storage/app/avatars/employee/$employees->photograph") ?>" width="100px" height="100px"/>
            <input type="file" id="photograph" name="photograph" accept="image/*" />
          </div>
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="tenth_marksheet">10th Marksheet</label>
            <img src="<?php echo asset("storage/app/avatars/tenth_marksheet/$employees->tenth_marksheet") ?>" width="100px" height="100px"/>
            <input type="file" id="tenth_marksheet" name="tenth_marksheet" accept="image/*" />
          </div>
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="twelth_marksheet">12th Marksheet</label>
            <img src="<?php echo asset("storage/app/avatars/twelth_marksheet/$employees->twelth_marksheet") ?>" width="100px" height="100px"/>
            <input type="file" id="twelth_marksheet" name="twelth_marksheet" accept="image/*" />
          </div>
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="graduation">Graduation(Last Qualification)</label>
            <img src="<?php echo asset("storage/app/avatars/graduation/$employees->graduation") ?>" width="100px" height="100px"/>
            <input type="file" id="graduation" name="graduation" accept="image/*" />
          </div>
        </div>

        <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="adhar_card_no">Adhar Card Number</label>
            <input type="text" class="form-control" name="adhar_card_no" value="<?php echo e($employees->adhar_card_no); ?>">
          </div>

          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="customer_id">Customer Id</label>
            <input type="text" class="form-control" name="customer_id" value="<?php echo e($employees->customer_id); ?>">
          </div>

          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="account_no">Account Number</label>
            <input type="text" class="form-control" name="account_no" value="<?php echo e($employees->account_no); ?>">
          </div>
          
       
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="margin-top:60px">
            <button type="submit" class="btn btn-success" style="margin-left:38px">Update</button>
          </div>
        </div>
      </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('employees.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>