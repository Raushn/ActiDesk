@extends('attendance.base')
@section('action-content')

@endsection