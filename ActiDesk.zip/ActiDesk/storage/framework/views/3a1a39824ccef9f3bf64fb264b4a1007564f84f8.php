<?php $__env->startSection('action-content'); ?>
     <div class="container">
      <div class="pull-right">
        <a class="btn btn-info" href="<?php echo e(action('DesignationController@create')); ?>"> Create New Designation</a>
      </div>
    <br />
    <hr>
   <!--  <div class="container"> -->
   <form action="designation/search" method="POST" role="search">
    <?php echo e(csrf_field()); ?>

    <div class="input-group">
        <input type="text" class="form-control" name="designation_name"
            placeholder="Search Designation Name"> <span class="input-group-btn">
            <button type="submit" class="btn btn-default">
                <span class="glyphicon glyphicon-search"></span>
            </button>
        </span>
   <!--  </div> -->
</form>
  </div>
  <br />
    <?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e(\Session::get('success')); ?></p>
      </div><br />
     <?php endif; ?>
    <table class="table table-striped">
    <thead>
      <tr>
        <th>SNo</th>
        <th>ID</th>
        <th>Designation Name</th>
       
        <th colspan="2">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $i=1; ?>
      <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
      <tr>
        <td><?php echo e($designations->firstItem() + $index); ?></td>
        <td><?php echo e($designation['id']); ?></td>
        <td><?php echo e($designation['designation_name']); ?></td>
        <td>    
           <form action="<?php echo e(route('designation.destroy',$designation['id'])); ?>" method="POST" onsubmit = "return confirm('Are you sure?')">
            <?php if (isset($_GET['page'])) {
              $page=$_GET['page'];
            ?>
             <a class="btn btn-info" href="<?php echo e(route('designation.show',$designation->id,['page'=>$page])); ?>">Show</a>
             <a class="btn btn-primary" href="<?php echo e(route('designation.edit',$designation->id,['page'=>$page])); ?>">Edit</a>
             <?php }else {?>
               <a class="btn btn-info" href="<?php echo e(route('designation.show',$designation->id)); ?>">Show</a>
             <a class="btn btn-primary" href="<?php echo e(route('designation.edit',$designation->id)); ?>">Edit</a>
              <?php } ?>
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
             <button type="submit" class="btn btn-danger">Delete</button>
            </form>
        </td>
      </tr>
      <?php $i++; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
 
 <?php echo $designations->links(); ?>

  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('designation.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>