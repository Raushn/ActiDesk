@extends('organization.base')
@section('action-content')
   <div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Organization Name</strong>
                {{ $organizations->organization_name }}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <?php if (isset($_GET['page'])) {
              $page=$_GET['page'];
            ?>
            <a  href="{{ route('organization.index',['page'=>$page])}}"><button type="button" class="btn btn-primary">
                Back
            </button></a>
            
            <?php } ?>
        </div>
       </div>
    </div>
@endsection