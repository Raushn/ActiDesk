<?php

namespace App\Http\Controllers\EmployerAuth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests;

//Trait
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;

//Password Broker Facade
use Illuminate\Support\Facades\Password;


class ForgotPasswordController extends Controller
{
    //Sends Password Reset emails
    use SendsPasswordResetEmails;

    //Shows form to request password reset
    public function showLinkRequestForm()
    {
        return view('employer.passwords.email');
    }

     //Password Broker for Employer Model
    public function broker()
    {
         return Password::broker('employers');
    }
}
