<?php $__env->startSection('action-content'); ?>
    <table class="table table-bordered">
      <tr>
       
                  <td><?php echo e($employees->id); ?></td>
                  <td><img width="50px" height="50px" src="<?php echo asset("storage/app/avatars/employee/$employee->photograph") ?>"/></td>
                  <td class="sorting_1"><?php echo e($employees->name); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->contact); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->email); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->address); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->organization); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->designation); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->date_of_joining); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->employee_code); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->date_of_birth); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->fathers_name); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->contact_2); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->nda); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->address_proof); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->pancard_no); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->photograph); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->tenth_marksheet); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->twelth_marksheet); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->graduation); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->adhar_card_no); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->customer_id); ?></td>
                  <td class="hidden-xs"><?php echo e($employees->account_no); ?></td>
      </tr>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employees.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>