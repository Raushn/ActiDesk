<?php $__env->startSection('action-content'); ?>
<div class="container">
      
      <form method="post" action="<?php echo e(url('designation')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="Designation Name">Designation Name</label>
            <input type="text" class="form-control" name="designation_name">
          </div>
        </div>
     
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="margin-top:60px">
            <button type="submit" class="btn btn-success">Submit</button>
          </div>
        </div>
      </form>
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('designation.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>