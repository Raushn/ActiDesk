<?php

namespace App\Http\Controllers\EmployerAuth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Illuminate\Foundation\Auth\ResetsPasswords;
//Auth Facade
use Illuminate\Support\Facades\Auth;

//Password Broker Facade
use Illuminate\Support\Facades\Password;

class ResetPasswordController extends Controller
{

	//Employer redirect path
    protected $redirectTo = '/employerhome';

    //trait for handling reset Password
    use ResetsPasswords;

    //Show form to employer where they can reset password
    public function showResetForm(Request $request, $token = null)
    {
        return view('employer.passwords.reset')->with(
            ['token' => $token, 'email' => $request->email]
        );
    }

     //returns Password broker of employer
    public function broker()
    {
        return Password::broker('employers');
    }

    //returns authentication guard of employer
    protected function guard()
    {
        return Auth::guard('web_employer');
    }
}
