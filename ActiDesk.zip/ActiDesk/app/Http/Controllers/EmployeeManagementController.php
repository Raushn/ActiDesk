<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Employer;
use App\Organization;
use App\Designation;
use PDF;
use DB;

class EmployeeManagementController extends Controller
{
    
     public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $employees= DB::table('employers')
       ->leftJoin('organizations', 'employers.organization_id', '=', 'organizations.id')
       ->leftJoin('designations', 'employers.designation_id', '=', 'designations.id')
       ->select('employers.*', 'organizations.id as organization_id', 'organizations.organization_name as organization_name', 'designations.id as designation_id', 'designations.designation_name as designation_name')
       ->latest()->paginate(4);
        return view('employees\index',compact('employees'))->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $organizations = Organization::all();
        $designations = Designation::all();
        return view('employees/create',['organizations' => $organizations , 'designations' => $designations]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $path_web=$request->file('photograph');
        $destinationPath = storage_path(). '/app/avatars/employee';
        $photograph = $path_web->getClientOriginalName();
        $path_web->move($destinationPath, $photograph);

        $path_web=$request->file('tenth_marksheet');
        $destinationPath = storage_path(). '/app/avatars/tenth';
        $tenth_marksheet = $path_web->getClientOriginalName();
        $path_web->move($destinationPath, $tenth_marksheet);

        $path_web=$request->file('twelth_marksheet');
        $destinationPath = storage_path(). '/app/avatars/twelth';
        $twelth_marksheet = $path_web->getClientOriginalName();
        $path_web->move($destinationPath, $twelth_marksheet);

        $path_web=$request->file('graduation');
        $destinationPath = storage_path(). '/app/avatars/graduation';
        $graduation = $path_web->getClientOriginalName();
        $path_web->move($destinationPath, $graduation);

         Employer::create([
            'name' => $request['name'],
            'contact' => $request['contact'],
            'email' => $request['email'],
            'password' => Hash::make($request['password']),
            
            'address' => $request['address'],
            'organization_id' => $request['organization_id'],
            'designation_id' => $request['designation_id'],
            'date_of_joining' => $request['date_of_joining'],
            'employee_code' => $request['employee_code'],
            'date_of_birth' => $request['date_of_birth'],
            'fathers_name' => $request['fathers_name'],
            'contact_2' => $request['contact_2'],
            'nda' => $request['nda'],
            'address_proof' => $request['address_proof'],
            'pancard_no' => $request['pancard_no'],
            'photograph' => $photograph,
            'tenth_marksheet' => $tenth_marksheet,
            'twelth_marksheet' => $twelth_marksheet,
            'graduation' => $graduation,
            'adhar_card_no' => $request['adhar_card_no'],
            'customer_id' => $request['customer_id'],
            'account_no' => $request['account_no']

        ]);
         // print_r($rm);
         // die();
        return redirect()->route('employees.index')->with('success','Employees created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
         $employees = \App\Employer::find($id);
         $organizations = Organization::all();
        $designations = Designation::all();
        return view('employees.edit',['organizations' => $organizations , 'designations' => $designations, 'employees' => $employees, 'id' => $id]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $employee= \App\Employer::find($id);
        $employee->name=$request->get('name');
        $employee->contact=$request->get('contact');
        $employee->email=$request->get('email');
        $employee->address=$request->get('address');
        $employee->organization_id=$request->get('organization_id');
        $employee->designation_id=$request->get('designation_id');
        $employee->date_of_joining=$request->get('date_of_joining');
        $employee->employee_code=$request->get('employee_code');
        $employee->date_of_birth=$request->get('date_of_birth');
        $employee->fathers_name=$request->get('fathers_name');
        $employee->contact_2=$request->get('contact_2');
        $employee->nda=$request->get('nda');
        $employee->address_proof=$request->get('address_proof');
        $employee->pancard_no=$request->get('pancard_no');

        if ($path_web = $request->file('photograph')) {
             $destinationPath = storage_path(). '/app/avatars/tenth';
             $tenth_marksheet = $path_web->getClientOriginalName();
             $path_web->move($destinationPath, $tenth_marksheet);
             $employee['photograph'] = $tenth_marksheet;
            }

        //$employee->photograph=$request->get('photograph');
        $employee->tenth_marksheet=$request->get('tenth_marksheet');
        $employee->twelth_marksheet=$request->get('twelth_marksheet');
        $employee->graduation=$request->get('graduation');
        $employee->adhar_card_no=$request->get('adhar_card_no');
        $employee->customer_id=$request->get('customer_id');
        $employee->account_no=$request->get('account_no');
        
        $employee->save();
        return redirect('employees')->with('success','Employee updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $employee = \App\Employer::find($id);
        $employee->delete();
        return redirect('employees')->with('success','Employee has been  deleted');
    }

    public function export_pdf(Request $request )
  {
    echo "helll";
    die();
    // Fetch all customers from database
    $data = Employer::get();
    // Send data to the view using loadView function of PDF facade
    $pdf = PDF::loadView('employers.pdf', $data);
    // If you want to store the generated pdf to the server then you can use the store function
    $pdf->save(storage_path().'_filename.pdf');
    // Finally, you can download the file using download function
    return $pdf->download('employers.pdf');
  }
}
