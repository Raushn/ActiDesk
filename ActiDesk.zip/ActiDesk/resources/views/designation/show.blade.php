@extends('designation.base')
@section('action-content')
   <div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Designation Name</strong>
                {{ $designations->designation_name }}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <?php if (isset($_GET['page'])) {
              $page=$_GET['page'];
            ?>
            <a  href="{{ route('designation.index',['page'=>$page])}}"><button type="button" class="btn btn-primary">
                Back
            </button></a>
            
            <?php } ?>
        </div>
       </div>
    </div>
@endsection