@extends('organization.base')
@section('action-content')
<div class="container">
      
      <form method="post" action="{{url('organization')}}" enctype="multipart/form-data">
        @csrf
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="Organization Name">Organization Name</label>
            <input type="text" class="form-control" name="organization_name">
          </div>
        </div>
     
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="margin-top:60px">
            <button type="submit" class="btn btn-success">Submit</button>
          </div>
        </div>
      </form>
    </div>
    

@endsection