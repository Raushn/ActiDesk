<?php $__env->startSection('action-content'); ?>
<style type="text/css">
  .container {
  width: 100%;
  overflow-x: auto;
  white-space: nowrap;
}

</style>
    <!-- Main content -->
   <div class="section" style="border: 2px solid red">
      <div class="pull-right">
        <a class="btn btn-info" href="<?php echo e(action('EmployeeManagementController@create')); ?>"> Create New Employee</a>
      </div>
    <br />
    <hr>
  
   <form action="employees/search" method="POST" role="search">
    <?php echo e(csrf_field()); ?>

    <!-- <div class="input-group" style="border: 2px solid green">
        <input type="text" class="control-label" name="name" placeholder="Search Employee Name">

        <input type="text" class="control-label" name="email" placeholder="Search Employee Email">
           <span class="input-group-btn">
            <button type="submit" class="btn btn-default">
                <span class="glyphicon glyphicon-search"></span>
            </button>
        </span>
    </div> -->
    <!-- <div class="col-md-12">
      <div class="form-group">
          <label for="input" class="col-sm-3 control-label">Name</label>
          <div class="col-sm-6">
            <input type="text" class="form-control" name="name" placeholder="Search Employee Name">
            
          </div>
          <label for="input" class="col-sm-3 control-label">Email</label>
          <div class="col-sm-6">
           
            <input type="text" class="form-control" name="email" placeholder="Search Employee Email">
          </div>
          
    <button type="submit" class="btn btn-primary">
      <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
      Search
    </button>
  
      </div>
    </div> -->
     <div class="panel-menu allcp-form theme-primary mtn">
                        <div class="row">
                             <form action="employees/search" method="POST" role="search">
    <?php echo e(csrf_field()); ?>

                            <div class="col-md-3">
                                <input type="text" class="field form-control" placeholder="query string" style="height:40px" value="name" name="name">
                            </div>
                            <div class="col-md-3">
                                <label class="field select">
                                  <select class="form-control js-organization" name="organization">
                                    <option value="-1">Please select your Organization</option>
                                    
                                        <option value="yhj">name</option>
                                   
                                </select>
                            </div>
                            <div class="col-md-2">
                                <input type="submit" value="Search" name="button" class="btn btn-primary">
                            </div>

                            <div class="col-md-2">
                               <a class="btn-btn-info" href="<?php echo e(action('EmployeeManagementController@export_pdf')); ?>">Export PDF</a>
                            </div>
                            </form>
                           
                        </div>
                            </div>
</form>
   <div class="container">
  <br />
    <?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e(\Session::get('success')); ?></p>
      </div><br />
     <?php endif; ?>
    <table class="table table-striped">
    <thead>
      <tr>
                <th>S No</th>
                <th>Employee Id</th>
                <th>Name</th>
                <th>Contact Number</th>
                <th>Email Id</th>
                <th>Address</th>
                <th>Organization</th>
                <th>Designation</th>
                <th>Date Of Joining</th>
                <th>Employee Code</th>
                <th>Date Of Birth</th>
                <th>Fathers Name</th>
                <th>Alternate Contact Number</th>
                <th>NDA</th>
                <th>Address Proof</th>
                <th>Pancard Number</th>
                <th>Photograph</th>
                <th>10th Marksheet</th>
                <th>12th Marksheet</th>
                <th>Graduation(Last Qualification)</th>
                <th>Adhar Card Number</th>
                <th>Customer Id</th>
                <th>Account Number</th>
                <th colspan="2">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $i=1; ?>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($employees->firstItem() + $index); ?></td>
                  <td><?php echo e($employee->id); ?></td>
                  
                  <td class="sorting_1"><?php echo e($employee->name); ?></td>
                  <td class="hidden-xs"><?php echo e($employee->contact); ?></td>
                  <td class="hidden-xs"><?php echo e($employee->email); ?></td>
                  <td class="hidden-xs"><?php echo e($employee->address); ?></td>
                  <td class="hidden-xs"><?php echo e($employee->organization_name); ?></td>
                  <td class="hidden-xs"><?php echo e($employee->designation_name); ?></td>
                  <td class="hidden-xs"><?php echo e($employee->date_of_joining); ?></td>
                  <td class="hidden-xs"><?php echo e($employee->employee_code); ?></td>
                  <td class="hidden-xs"><?php echo e($employee->date_of_birth); ?></td>
                  <td class="hidden-xs"><?php echo e($employee->fathers_name); ?></td>
                  <td class="hidden-xs"><?php echo e($employee->contact_2); ?></td>
                  <td class="hidden-xs"><?php echo e($employee->nda); ?></td>
                  <td class="hidden-xs"><?php echo e($employee->address_proof); ?></td>
                  <td class="hidden-xs"><?php echo e($employee->pancard_no); ?></td>
                  <td><img src="<?php echo asset("storage/app/avatars/employee/$employee->photograph") ?>" width="50px" height="50px"/></td>
                  <td><img src="<?php echo asset("storage/app/avatars/tenth/$employee->tenth_marksheet") ?>" width="50px" height="50px"/></td>
                  <td><img src="<?php echo asset("storage/app/avatars/twelth/$employee->twelth_marksheet") ?>" width="50px" height="50px"/></td>
                   <td><img src="<?php echo asset("storage/app/avatars/graduation/$employee->graduation") ?>" width="50px" height="50px"/></td>
                  <td class="hidden-xs"><?php echo e($employee->adhar_card_no); ?></td>
                  <td class="hidden-xs"><?php echo e($employee->customer_id); ?></td>
                  <td class="hidden-xs"><?php echo e($employee->account_no); ?></td>
                  

                  <td>
                    <form class="row" method="POST" action="<?php echo e(route('employees.destroy', ['id' => $employee->id])); ?>" onsubmit = "return confirm('Are you sure?')">
                    
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <a href="<?php echo e(route('employees.edit', ['id' => $employee->id])); ?>" class="btn btn-primary ">Edit</a>
                        <a href="<?php echo e(route('employees.show', ['id' => $employee->id])); ?>" class="btn btn-info ">Show</a>
                         <button type="submit" class="btn btn-danger">
                          Delete
                        </button>
                    </form>
                  </td>
              </tr>
              <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>
  </table>
              

       
      <?php echo $employees->links(); ?>


  </div> 
 </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('employees.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>