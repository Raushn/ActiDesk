<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEmployersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employers', function (Blueprint $table) {
             $table->increments('id');
             $table->string('name');
            $table->string('contact')->unique();
            $table->string('email')->unique();
            $table->string('password');
            $table->rememberToken();
            $table->string('address');
            $table->integer('organization_id');
            $table->integer('designation_id');
            $table->date('date_of_joining');
            $table->string('employee_code');
            $table->date('date_of_birth');
            $table->string('fathers_name');
            $table->string('contact_2');
            $table->string('nda');
            $table->string('address_proof');
            $table->string('pancard_no');
            $table->string('photograph');
            $table->string('tenth_marksheet');
            $table->string('twelth_marksheet');
            $table->string('graduation');
            $table->string('adhar_card_no');
            $table->string('customer_id');
            $table->string('account_no');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employers');
    }
}
