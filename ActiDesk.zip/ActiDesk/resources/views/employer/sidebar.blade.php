<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<!-- Sidebar -->
<div class="w3-sidebar w3-light-grey w3-bar-block" style="width:15%">
  <h3 class="w3-bar-item">Menu</h3>
  <li class="{{ set_active('dashboard') }}"><a href="{{ url('dashboard') }}" class="w3-bar-item w3-button">Link 1</a></li>
  <li><a href="#" class="w3-bar-item w3-button">Link 2</a></li>
  <li><a href="#" class="w3-bar-item w3-button">Link 3</a></li>
</div>