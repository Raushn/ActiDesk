@extends('designation.base')
@section('action-content')
     <div class="container">
      <div class="pull-right">
        <a class="btn btn-info" href="{{action('DesignationController@create') }}"> Create New Designation</a>
      </div>
    <br />
    <hr>
   <!--  <div class="container"> -->
   <form action="designation/search" method="POST" role="search">
    {{ csrf_field() }}
    <div class="input-group">
        <input type="text" class="form-control" name="designation_name"
            placeholder="Search Designation Name"> <span class="input-group-btn">
            <button type="submit" class="btn btn-default">
                <span class="glyphicon glyphicon-search"></span>
            </button>
        </span>
   <!--  </div> -->
</form>
  </div>
  <br />
    @if (\Session::has('success'))
      <div class="alert alert-success">
        <p>{{ \Session::get('success') }}</p>
      </div><br />
     @endif
    <table class="table table-striped">
    <thead>
      <tr>
        <th>SNo</th>
        <th>ID</th>
        <th>Designation Name</th>
       
        <th colspan="2">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $i=1; ?>
      @foreach($designations as $index => $designation)
   
      <tr>
        <td>{{ $designations->firstItem() + $index }}</td>
        <td>{{$designation['id']}}</td>
        <td>{{$designation['designation_name']}}</td>
        <td>    
           <form action="{{ route('designation.destroy',$designation['id']) }}" method="POST" onsubmit = "return confirm('Are you sure?')">
            <?php if (isset($_GET['page'])) {
              $page=$_GET['page'];
            ?>
             <a class="btn btn-info" href="{{ route('designation.show',$designation->id,['page'=>$page]) }}">Show</a>
             <a class="btn btn-primary" href="{{ route('designation.edit',$designation->id,['page'=>$page]) }}">Edit</a>
             <?php }else {?>
               <a class="btn btn-info" href="{{ route('designation.show',$designation->id) }}">Show</a>
             <a class="btn btn-primary" href="{{ route('designation.edit',$designation->id) }}">Edit</a>
              <?php } ?>
              @csrf
              @method('DELETE')
             <button type="submit" class="btn btn-danger">Delete</button>
            </form>
        </td>
      </tr>
      <?php $i++; ?>
      @endforeach
    </tbody>
  </table>
 
 {!! $designations->links() !!}
  </div>

@endsection