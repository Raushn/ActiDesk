<?php $__env->startSection('action-content'); ?>
   <div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Designation Name</strong>
                <?php echo e($designations->designation_name); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <?php if (isset($_GET['page'])) {
              $page=$_GET['page'];
            ?>
            <a  href="<?php echo e(route('designation.index',['page'=>$page])); ?>"><button type="button" class="btn btn-primary">
                Back
            </button></a>
            
            <?php } ?>
        </div>
       </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('designation.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>