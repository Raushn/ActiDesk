<?php $__env->startSection('action-content'); ?>
<div class="container">
     
        <form method="post" action="<?php echo e(action('DesignationController@update', $id)); ?>">
        <?php echo csrf_field(); ?>
        <input name="_method" type="hidden" value="PATCH">
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="designation_name">Designation Name</label>
            <input type="text" class="form-control" name="designation_name" value="<?php echo e($designations->designation_name); ?>">
          </div>
        </div>
      
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="margin-top:60px">
            <button type="submit" class="btn btn-success" style="margin-left:38px">Update</button>
          </div>
        </div>
      </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('designation.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>