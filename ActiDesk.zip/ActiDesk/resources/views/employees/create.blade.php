@extends('employees.base')
@section('action-content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Add new employee</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="{{ route('employees.store') }}" enctype="multipart/form-data">
                        {{ csrf_field() }}
                        <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="{{ old('name') }}" required autofocus>

                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group{{ $errors->has('contact') ? ' has-error' : '' }}">
                            <label for="contact" class="col-md-4 control-label">Contact Number</label>

                            <div class="col-md-6">
                                <input id="contact" type="text" class="form-control" name="contact" value="{{ old('contact') }}" required>

                                @if ($errors->has('contact'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('contact') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">Email Id</label>

                            <div class="col-md-6">
                                <input id="email" type="text" class="form-control" name="email" value="{{ old('email') }}" required>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="text" class="form-control" name="password" value="{{ old('password') }}" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('address') ? ' has-error' : '' }}">
                            <label for="address" class="col-md-4 control-label">Address</label>

                            <div class="col-md-6">
                                <input id="address" type="text" class="form-control" name="address" value="{{ old('address') }}" required>

                                @if ($errors->has('address'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('address') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Organization</label>
                            <div class="col-md-6">
                                <select class="form-control js-organization" name="organization_id">
                                    <option value="">Please select your Organization</option>
                                    @foreach ($organizations as $organization)
                                        <option value="{{$organization->id}}">{{$organization->organization_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 control-label">Designation</label>
                            <div class="col-md-6">
                                <select class="form-control js-designations" name="designation_id">
                                    <option value="">Please select your Designation</option>
                                    @foreach ($designations as $designation)
                                        <option value="{{$designation->id}}">{{$designation->designation_name}}</option>
                                    @endforeach 
                                </select>
                            </div>
                        </div>

                         <div class="form-group">
                            <label class="col-md-4 control-label">Date of Joining</label>
                            <div class="col-md-6">
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" value="{{ old('date_of_joining') }}" name="date_of_joining" class="form-control pull-right" id="date_of_joining" required>
                                </div>
                            </div>
                        </div>

                         <div class="form-group{{ $errors->has('employee_code') ? ' has-error' : '' }}">
                            <label for="employee_code" class="col-md-4 control-label">Employee Code</label>

                            <div class="col-md-6">
                                <input id="employee_code" type="text" class="form-control" name="employee_code" value="{{ old('employee_code') }}" required>

                                @if ($errors->has('employee_code'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('employee_code') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                         <div class="form-group">
                            <label class="col-md-4 control-label">Birthday</label>
                            <div class="col-md-6">
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" value="{{ old('date_of_birth') }}" name="date_of_birth" class="form-control pull-right" id="date_of_birth" required>
                                </div>
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('fathers_name') ? ' has-error' : '' }}">
                            <label for="fathers_name" class="col-md-4 control-label">Father's Name</label>

                            <div class="col-md-6">
                                <input id="fathers_name" type="text" class="form-control" name="fathers_name" value="{{ old('fathers_name') }}" required>

                                @if ($errors->has('fathers_name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('fathers_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                       
                        <div class="form-group{{ $errors->has('contact_2') ? ' has-error' : '' }}">
                            <label for="contact_2" class="col-md-4 control-label">Alternate Contact Number</label>

                            <div class="col-md-6">
                                <input id="contact_2" type="text" class="form-control" name="contact_2" value="{{ old('contact_2') }}" required>

                                @if ($errors->has('contact_2'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('contact_2') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('nda') ? ' has-error' : '' }}">
                            <label for="nda" class="col-md-4 control-label">NDA</label>

                            <div class="col-md-6">
                                <input id="nda" type="text" class="form-control" name="nda" value="{{ old('nda') }}" required>

                                @if ($errors->has('nda'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('nda') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('address_proof') ? ' has-error' : '' }}">
                            <label for="nda" class="col-md-4 control-label">Address Proof</label>

                            <div class="col-md-6">
                                <input id="address_proof" type="text" class="form-control" name="address_proof" value="{{ old('address_proof') }}" required>

                                @if ($errors->has('address_proof'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('address_proof') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group{{ $errors->has('pancard_no') ? ' has-error' : '' }}">
                            <label for="pancard_no" class="col-md-4 control-label">Pancard Number</label>

                            <div class="col-md-6">
                                <input id="pancard_no" type="text" class="form-control" name="pancard_no" value="{{ old('pancard_no') }}" required>

                                @if ($errors->has('pancard_no'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('pancard_no') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="avatar" class="col-md-4 control-label" >Picture</label>
                            <div class="col-md-6">
                                <input type="file" id="photograph" name="photograph" required >
                            </div>
                        </div>
                       
                        <div class="form-group">
                            <label for="avatar" class="col-md-4 control-label" >10th Marksheet</label>
                            <div class="col-md-6">
                                <input type="file" id="tenth_marksheet" name="tenth_marksheet" required >
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="avatar" class="col-md-4 control-label" >12th Marksheet</label>
                            <div class="col-md-6">
                                <input type="file" id="twelth_marksheet" name="twelth_marksheet" required >
                            </div>
                        </div>

                         <div class="form-group">
                            <label for="avatar" class="col-md-4 control-label" >Graduation(Last Qualification)</label>
                            <div class="col-md-6">
                                <input type="file" id="graduation" name="graduation" required >
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('adhar_card_no') ? ' has-error' : '' }}">
                            <label for="adhar_card_no" class="col-md-4 control-label">Adhar Card Number</label>

                            <div class="col-md-6">
                                <input id="adhar_card_no" type="text" class="form-control" name="adhar_card_no" value="{{ old('adhar_card_no') }}" required>

                                @if ($errors->has('adhar_card_no'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('adhar_card_no') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group{{ $errors->has('customer_id') ? ' has-error' : '' }}">
                            <label for="customer_id" class="col-md-4 control-label">Customer Id</label>

                            <div class="col-md-6">
                                <input id="customer_id" type="text" class="form-control" name="customer_id" value="{{ old('customer_id') }}" required>

                                @if ($errors->has('customer_id'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('customer_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                         <div class="form-group{{ $errors->has('account_no') ? ' has-error' : '' }}">
                            <label for="account_no" class="col-md-4 control-label">Account Number</label>

                            <div class="col-md-6">
                                <input id="account_no" type="text" class="form-control" name="account_no" value="{{ old('account_no') }}" required>

                                @if ($errors->has('account_no'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('account_no') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                         
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Create
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection